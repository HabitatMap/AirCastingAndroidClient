#include <Arduino.h>
#include <SoftwareSerial.h>
#include <TimeLib.h>
#include "Time_Sync.h"
#include "Color.h";

extern SoftwareSerial cellular_Serial;

char replybuffer[17];  

extern int years;
extern int months;
extern int days;
extern int hours;
extern int mins;
extern int secs;
extern byte i;
extern String ip;
extern int trigger;

void ShowSerialData()
{
  while(cellular_Serial.available()){
    Serial.write(cellular_Serial.read()); 
  }
}

void SetSMSTime(){
  i = 0;
  cellular_Serial.print("AT+COPS=0\r\n");
  while(!cellular_Serial.find("OK") && i++ <5){
    pms();
    cellular_Serial.print("AT+COPS=0\r\n");
  }
  if (i == 6){
    Serial.println(F("Could Not Register Network"));
  }
  else {
    Serial.println(F("Registered Network"));
  }
  Serial.println(F("Searching for Date and Time:"));
  cellular_Serial.print("AT+CCLK?\r\n");
  cellular_Serial.find("+CCLK: \"");
  cellular_Serial.readBytesUntil('"',replybuffer,18);
  //Serial.println(replybuffer);
  years = atoi(strtok(replybuffer, "/"));
  months = atoi(strtok(NULL, "/"));
  days = atoi(strtok(NULL, ","));
  hours = atoi(strtok(NULL, ":"));  
  mins = atoi(strtok(NULL, ":"));
  secs = atoi(strtok(NULL, "-"));
  while(1){
    if((years != 0) && (months != 0) && (days != 0)){
      setTime(hours, mins, secs, days, months, years);
      break;
    }
    else{
      Serial.println(F("Time Error, Setting Time Again"));
      i = 0;
      cellular_Serial.print("AT+COPS=0\r\n");
      while(!cellular_Serial.find("OK") && i++ <5){
        pms();
        cellular_Serial.print("AT+COPS=0\r\n");
      }
      if (i == 6){
        Serial.println(F("Could Not Register Network"));
      }
      else {
        Serial.println(F("Registered Network"));
      }
      cellular_Serial.print("AT+CCLK?\r\n");
      cellular_Serial.find("+CCLK: \"");
      cellular_Serial.readBytesUntil('"',replybuffer,18);
      //Serial.println(replybuffer);
      years = atoi(strtok(replybuffer, "/"));
      months = atoi(strtok(NULL, "/"));
      days = atoi(strtok(NULL, ","));
      hours = atoi(strtok(NULL, ":"));  
      mins = atoi(strtok(NULL, ":"));
      secs = atoi(strtok(NULL, "-"));
    }
  }
  Serial.print(F("Set Date: "));
  Serial.print(printDigits(months));
  Serial.print(F("/"));
  Serial.print(printDigits(days));
  Serial.print(F("/"));
  Serial.print(printDigits_year(years));
  Serial.print(F(" Set Time: "));
  Serial.print(printDigits(hours));
  Serial.print(F(":"));
  Serial.print(printDigits(mins));
  Serial.print(F(":"));
  Serial.println(printDigits(secs));
}







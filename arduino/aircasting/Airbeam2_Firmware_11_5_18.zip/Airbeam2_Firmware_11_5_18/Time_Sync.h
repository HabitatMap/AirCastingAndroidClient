#ifndef TIME_SYNC_HEADER
#define TIME_SYNC_HEADER

int printDigits(int digits);
int printDigits_year(int digits);
uint8_t DST(int Zone, int years, int months, int days, int hours);
void WiFitimesync();
void SetSMSTime();
void open_TCP_WiFi();
void pms();
void load_saved_config();
void serial_debugger();

#endif

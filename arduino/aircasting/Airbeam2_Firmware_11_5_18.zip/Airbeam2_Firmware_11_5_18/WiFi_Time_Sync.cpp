#include <Arduino.h>
#include <SoftwareSerial.h>
#include <TimeLib.h>
#include "Time_Sync.h"
#include "Strings.h"

extern SoftwareSerial wifi_Serial;

String datetime;
unsigned long begintime_;
unsigned long elapsedtime_;
boolean USDSTflag;
boolean EURDSTflag;
boolean datetimeflag;
extern int years;
extern int months;
extern int days;
extern int hours;
extern int mins;
extern int secs;
extern int Zone;
extern char buff[];
extern byte i;
extern String Aircastingserver;
extern String ip;

void TimeZonefromGMT(int Zone, int months, int days, int years, int hours, int mins, int secs) {
  hours = hours + Zone;
  if (hours < 1) {
    hours = hours + 24;
    if (hours == 24) {
      hours = 0;
    }
    else {
      days = days - 1;
    }
    if (days < 1) {
      months = months - 1;
      if (months == 0) {
        months = 12;
        days = 31;
        years = years - 1;
      }
      if (months == 1)
        days = 31;
      if (months == 2) {
        if (years % 4 == 0) {
          days = 29;
        }
        else
          days = 28;
      } 
      if (months == 3)
        days = 31;
      if (months == 4)
        days = 30;
      if (months == 5)
        days = 31;
      if (months == 6)
        days = 30;
      if (months == 7)
        days = 31;
      if (months == 8)
        days = 31;
      if (months == 9)
        days = 30;
      if (months == 10)
        days = 31;
      if (months == 11)
        days = 30;
    }
  }
  if (hours > 23) {
    hours = hours - 24;
    if (((months == 1 && days == 31) || (months == 2 && days == 29 && years % 4 == 0) || (months == 2 && days == 28 && years % 4 != 0) || (months == 3 && days == 31) || (months == 4 && days == 30) || (months == 5 && days == 31) || (months == 6 && days == 30) || (months == 7 && days == 31) || (months == 8 && days == 31) || (months == 9 && days == 30) || (months == 10 && days == 31) || (months == 11 && days == 30) || (months == 12 && days == 31))) {
      months = months + 1;
      days = 1;
    }
    else
      days = days + 1;
  }
  setTime(DST(Zone, years, months, days, hours), mins, secs + ((elapsedtime_ - begintime_)/1000), days, months, years);
}

uint8_t DST(int Zone, int years, int months, int days, int hours) {
  int y = years % 100;
  if(Zone == -5 || Zone == -6 || Zone == -7 || Zone == -8 || Zone == -9){
    int marday = (y + (y / 4) + 2) % 7;
    int novday = (y + (y / 4) + 2) % 7;

    if ((months == 3 && days == (14 - marday) && hours > 1) || (months == 11 && days == (7 - novday) && hours <= 1) || (months == 3 && days > (14 - marday)) || (months == 11 && days < (7 - novday)) || (months > 3 && months < 11)) {
      USDSTflag = true;
      Serial.println(F("US DST On"));
    }
    if ((months == 11 && days == (7 - novday) && hours > 1) || (months == 3 && days == (14 - marday) && hours <= 1) || (months == 11 && days > (7 - novday)) || (months == 3 && days < (14 - marday)) || (months < 3 && months > 11)) {
      USDSTflag = false;
      Serial.println(F("US DST Off"));
    }

    if (USDSTflag == true)
    {
      return hours + 1;
    }
    else{
      return hours; 
    }
  }
  if(Zone == 0 || Zone == 1 || Zone == 2){
    int marday = (y + (y / 4) + 2) % 7;
    int octday = (y + (y / 4) + 6) % 7;
    if ((months == 3 && days == (28 - marday) && hours > 1) || (months == 10 && days == (28 - octday) && hours <= 1) || (months == 3 && days > (28 - marday)) || (months == 10 && days < (28 - octday)) || (months > 3 && months < 10)) {
      EURDSTflag = true;
      Serial.println(F("EUR DST On"));
    }
    if ((months == 10 && days == (28 - octday) && hours > 1) || (months == 3 && days == (28 - marday) && hours <= 1) || (months == 10 && days > (28 - octday)) || (months == 3 && days < (28 - marday)) || (months < 3 && months > 10)) {
      EURDSTflag = false;
      Serial.println(F("EUR DST Off"));
    }
    if (EURDSTflag == true)
    {
      return hours + 1;
    }
    else{
      return hours; 
    }
  }
}

void WiFitimesync() {
  String TimeHEADrequest;
  open_TCP_WiFi();
  strcpy_P(buff, (char*)pgm_read_word(&(time_request_table[0])));
  TimeHEADrequest += buff;
  TimeHEADrequest += Aircastingserver;
  strcpy_P(buff, (char*)pgm_read_word(&(time_request_table[1])));
  TimeHEADrequest += buff;
  i = 0;
  wifi_Serial.print("AT+CIPSEND=" + String(TimeHEADrequest.length()) + "\r\n");  //Send data
  while(!wifi_Serial.find(">") && i++ <5) {  // CHECK PM
    pms();
    serial_debugger();
  }
  if (i == 6){
    Serial.println(F("> Not Found"));
  }
  else {
    Serial.println(F("> Found"));
  }
  wifi_Serial.print(TimeHEADrequest);
  wifi_Serial.print("\r\n");
  //Serial.print(TimeHEADrequest);
  begintime_ = millis();
  Serial.print(F("Searching for Date and Time:"));
  i = 0;
  while(!wifi_Serial.find("Date: ") && i++ < 10)
  {
    pms();
    serial_debugger();
    Serial.print(F("."));
  }
  if (i == 11) {
    Serial.println(F(" Time Sync Error"));
    datetimeflag = false;
  }
  else {
    Serial.println(F(" Done"));
    datetimeflag = true;
  } 
  datetime = "";
  for (int i = 0; i < 25; i++)
  {
    pms();
    if(wifi_Serial.available())
    {
      char c = wifi_Serial.read();
      //Serial.write(c);
      datetime += String(c);
    }
  }
  if(datetimeflag == true){
    years = datetime.substring(12, 16).toInt();
    if (datetime.substring(8, 11) == "Jan") {
      months = 1;
    }
    if (datetime.substring(8, 11) == "Feb") {
      months = 2;
    }
    if (datetime.substring(8, 11) == "Mar") {
      months = 3;
    }
    if (datetime.substring(8, 11) == "Apr") {
      months = 4;
    }
    if (datetime.substring(8, 11) == "May") {
      months = 5;
    }
    if (datetime.substring(8, 11) == "Jun") {
      months = 6;
    }
    if (datetime.substring(8, 11) == "Jul") {
      months = 7;
    }
    if (datetime.substring(8, 11) == "Aug") {
      months = 8;
    }
    if (datetime.substring(8, 11) == "Sep") {
      months = 9;
    }
    if (datetime.substring(8, 11) == "Oct") {
      months = 10;
    }
    if (datetime.substring(8, 11) == "Nov") {
      months = 11;
    }
    if (datetime.substring(8, 11) == "Dec") {
      months = 12;
    }
    days = datetime.substring(5, 7).toInt();
    hours = datetime.substring(17, 19).toInt();
    mins = datetime.substring(20, 22).toInt();
    secs = datetime.substring(23, 25).toInt();
    elapsedtime_ = millis();
    //Serial.println((years - year()));
    //Serial.println((elapsedtime_ - begintime_)/1000);
    if(((years - year()) < 2 && (years - year()) >= 0) || year() == 1970){ //First condition checks if synced year and year on AB2 difference is less than 2 and greater and equal to 0 do time sync, the second condition checks if the year is 1970 (the start time) then it must sync.
      TimeZonefromGMT(Zone, months, days, years, hours, mins, secs);
      Serial.print(F("Set Date: "));
      Serial.print(printDigits(month()));
      Serial.print(F("/"));
      Serial.print(printDigits(day()));
      Serial.print(F("/"));
      Serial.print(year());
      Serial.print(F(" Set Time: "));
      Serial.print(printDigits(hour()));
      Serial.print(F(":"));
      Serial.print(printDigits(minute()));
      Serial.print(F(":"));
      Serial.println(printDigits(second()));
    }
    else{
      Serial.print(F("Set Date: "));
      Serial.print(printDigits(month()));
      Serial.print(F("/"));
      Serial.print(printDigits(day()));
      Serial.print(F("/"));
      Serial.print(year());
      Serial.print(F(" Set Time: "));
      Serial.print(printDigits(hour()));
      Serial.print(F(":"));
      Serial.print(printDigits(minute()));
      Serial.print(F(":"));
      Serial.println(printDigits(second()));
    }
  }
  else{
    Serial.print(F("Set Date: "));
    Serial.print(printDigits(month()));
    Serial.print(F("/"));
    Serial.print(printDigits(day()));
    Serial.print(F("/"));
    Serial.print(year());
    Serial.print(F(" Set Time: "));
    Serial.print(printDigits(hour()));
    Serial.print(F(":"));
    Serial.print(printDigits(minute()));
    Serial.print(F(":"));
    Serial.println(printDigits(second()));
  }
}


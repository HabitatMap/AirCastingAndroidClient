#ifndef TIME_SYNC_HEADER
#define TIME_SYNC_HEADER

byte WiFitimesync();

String printDigitsYear(byte digits);

byte sensors();

#endif

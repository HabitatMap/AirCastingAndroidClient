#ifndef COLOR_HEADER
#define COLOR_HEADER

void red(byte bright);
void green(byte bright);
void blue(byte bright);
void magenta(byte bright);
void cyan(byte bright);
void yellow(byte bright);
void white(byte bright);
void orange(byte bright);
void purple(byte bright);
void off();

#endif

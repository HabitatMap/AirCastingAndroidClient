#ifndef BUILD_STRING_HEADER
#define BUILD_STRING_HEADER

String getPost();
String getData_1(int stream);
String getData_2(int stream);
String getData_3(int years, int months, int days, int hours, int mins, int secs, int sensor_value);

String printDigits(byte digits);
String printDigitsYear(byte digits);

#endif

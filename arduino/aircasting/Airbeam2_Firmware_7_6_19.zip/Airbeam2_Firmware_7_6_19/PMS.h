#ifndef PMS_HEADER
#define PMS_HEADER

#define pt_Serial Serial1

void pms();
void pms_average();

#endif

#ifndef READ_EEPROM_HEADER
#define READ_EEPROM_HEADER

void read_eeprom();

#endif

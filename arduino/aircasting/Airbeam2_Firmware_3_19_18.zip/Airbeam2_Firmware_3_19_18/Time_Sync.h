#ifndef TIME_SYNC_HEADER
#define TIME_SYNC_HEADER

void WiFitimesync();
void SetSMSTime();
void open_TCP_WiFi();
void pms();

#endif

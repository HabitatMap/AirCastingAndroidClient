#ifndef PMS_HEADER
#define PMS_HEADER

#define pt_Serial Serial1

void pms();
void pms_average();
void pms_bt();
int pms_check(); //Function to check PMS

#endif

#ifndef COLOR_HEADER
#define COLOR_HEADER

#define red_led A3
#define green_led A4
#define blue_led A5

void red();
void green();
void blue();
void magenta();
void cyan();
void yellow();
void white();
void off();

#endif

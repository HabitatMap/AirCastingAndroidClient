#ifndef BUILD_STRINGS_H
#define BUILD_STRINGS_H

void getPost();
void getData_1(int stream);
void getData_2(int stream);
void getData_3(int years, int months, int days, int hours, int mins, int secs, int sensor_value);

#endif
